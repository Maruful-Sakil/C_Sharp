﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviePlex
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        munibaEntities db = new munibaEntities();
        private void button1_Click(object sender, EventArgs e)
        {

            tablesignup obj = new tablesignup();
            obj.firstname = textfirstname.Text;
            obj.lastname = txtlastname.Text;
            obj.gender = gendercomboBox1.Text ;
            obj.dateofbirth = dateofbirth.Text;
            obj.email = email.Text;
            obj.phone = phone.Text;
            obj.username = username.Text;
            obj.password = password.Text;
            obj.region = region.Text;
            if(radioButton4.Checked) {
                obj.subscriptiontype = "Monthly";
                
            }
            else if(radioButton5.Checked)
            {
                obj.subscriptiontype = "Life Time";
            }
            else if (radioButton1.Checked)
            {
                obj.subscriptiontype = "Free";
            }

             obj.paymentmethod = paymentmethod.Text;
            db.tablesignups.Add(obj);
            db.SaveChanges();
            
            if (string.IsNullOrEmpty(textfirstname.Text) == true)
            {

                errorProvider1.SetError(this.textfirstname, " Please fill out");
            }
            else
            {
                errorProvider1.Clear();

                if (string.IsNullOrEmpty(txtlastname.Text) == true)
                {

                    errorProvider2.SetError(this.txtlastname, " Please fill out");
                }
                else
                {
                    errorProvider2.Clear();

                  

                        if (string.IsNullOrEmpty(dateofbirth.Text) == true)
                        {

                            errorProvider4.SetError(this.dateofbirth, " Please fill out");
                        }
                        else
                        {
                            errorProvider4.Clear();

                            if (string.IsNullOrEmpty(email.Text) == true)
                            {

                                errorProvider5.SetError(this.email, " Please fill out");
                            }
                            else
                            {
                                errorProvider5.Clear();

                                if (string.IsNullOrEmpty(phone.Text) == true)
                                {

                                    errorProvider6.SetError(this.phone, " Please fill out");
                                }
                                else
                                {
                                    errorProvider6.Clear();

                                    if (string.IsNullOrEmpty(username.Text) == true)
                                    {

                                        errorProvider7.SetError(this.username, " Please fill out");
                                    }
                                    else
                                    {
                                        errorProvider7.Clear();

                                    progressBar1.Visible = true;
                                    progressBar1.Increment(100);
                                    MessageBox.Show("Sign up Complete", "success",MessageBoxButtons.OK,MessageBoxIcon.Information);

                                    
                                    this.Hide();
                                                Form1 f1 = new Form1();
                                                f1.Show();
                                            }


                                        }


                                    }
                                }
                            }
                        }
                    }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void region_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }
    }
            }
        
    

