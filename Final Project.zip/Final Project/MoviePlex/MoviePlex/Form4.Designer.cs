﻿
namespace MoviePlex
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.slidePic6 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.slidePic1 = new System.Windows.Forms.PictureBox();
            this.button7 = new System.Windows.Forms.Button();
            this.slidePic5 = new System.Windows.Forms.PictureBox();
            this.slidePic4 = new System.Windows.Forms.PictureBox();
            this.slidePic3 = new System.Windows.Forms.PictureBox();
            this.slidePic2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panelmenu = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic2)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelmenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // slidePic6
            // 
            this.slidePic6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slidePic6.BackgroundImage")));
            this.slidePic6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidePic6.Location = new System.Drawing.Point(633, 276);
            this.slidePic6.Name = "slidePic6";
            this.slidePic6.Size = new System.Drawing.Size(156, 84);
            this.slidePic6.TabIndex = 34;
            this.slidePic6.TabStop = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(0, 270);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(200, 90);
            this.button4.TabIndex = 4;
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Blue;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(0, 180);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(200, 90);
            this.button3.TabIndex = 3;
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // slidePic1
            // 
            this.slidePic1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slidePic1.BackgroundImage")));
            this.slidePic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidePic1.Location = new System.Drawing.Point(207, 98);
            this.slidePic1.Name = "slidePic1";
            this.slidePic1.Size = new System.Drawing.Size(156, 84);
            this.slidePic1.TabIndex = 29;
            this.slidePic1.TabStop = false;
            this.slidePic1.Click += new System.EventHandler(this.slidePic1_Click);
            // 
            // button7
            // 
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.ForeColor = System.Drawing.Color.Transparent;
            this.button7.Location = new System.Drawing.Point(0, 360);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(200, 90);
            this.button7.TabIndex = 5;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // slidePic5
            // 
            this.slidePic5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slidePic5.BackgroundImage")));
            this.slidePic5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidePic5.Location = new System.Drawing.Point(422, 276);
            this.slidePic5.Name = "slidePic5";
            this.slidePic5.Size = new System.Drawing.Size(156, 84);
            this.slidePic5.TabIndex = 33;
            this.slidePic5.TabStop = false;
            // 
            // slidePic4
            // 
            this.slidePic4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slidePic4.BackgroundImage")));
            this.slidePic4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidePic4.Location = new System.Drawing.Point(207, 276);
            this.slidePic4.Name = "slidePic4";
            this.slidePic4.Size = new System.Drawing.Size(156, 84);
            this.slidePic4.TabIndex = 32;
            this.slidePic4.TabStop = false;
            // 
            // slidePic3
            // 
            this.slidePic3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slidePic3.BackgroundImage")));
            this.slidePic3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidePic3.Location = new System.Drawing.Point(633, 98);
            this.slidePic3.Name = "slidePic3";
            this.slidePic3.Size = new System.Drawing.Size(156, 84);
            this.slidePic3.TabIndex = 31;
            this.slidePic3.TabStop = false;
            // 
            // slidePic2
            // 
            this.slidePic2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slidePic2.BackgroundImage")));
            this.slidePic2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slidePic2.Location = new System.Drawing.Point(422, 98);
            this.slidePic2.Name = "slidePic2";
            this.slidePic2.Size = new System.Drawing.Size(156, 84);
            this.slidePic2.TabIndex = 30;
            this.slidePic2.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 90);
            this.button1.TabIndex = 1;
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(200, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 90);
            this.panel1.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(240, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Old Moveis";
            // 
            // panelmenu
            // 
            this.panelmenu.BackColor = System.Drawing.Color.Transparent;
            this.panelmenu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelmenu.BackgroundImage")));
            this.panelmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelmenu.Controls.Add(this.button7);
            this.panelmenu.Controls.Add(this.button4);
            this.panelmenu.Controls.Add(this.button3);
            this.panelmenu.Controls.Add(this.button2);
            this.panelmenu.Controls.Add(this.button1);
            this.panelmenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelmenu.Location = new System.Drawing.Point(0, 0);
            this.panelmenu.Name = "panelmenu";
            this.panelmenu.Size = new System.Drawing.Size(200, 450);
            this.panelmenu.TabIndex = 27;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Maroon;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(0, 90);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(200, 90);
            this.button2.TabIndex = 2;
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(217, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 18);
            this.label2.TabIndex = 35;
            this.label2.Text = "Bangla Subtitles";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(428, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 18);
            this.label3.TabIndex = 36;
            this.label3.Text = "English Subtitles";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(649, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 18);
            this.label4.TabIndex = 37;
            this.label4.Text = "Hindi Subtitles";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(217, 376);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 18);
            this.label5.TabIndex = 38;
            this.label5.Text = "Korean Subtitles";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(428, 376);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(123, 18);
            this.label6.TabIndex = 39;
            this.label6.Text = "Arabic Subtitles";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Rockwell", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(645, 376);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 18);
            this.label7.TabIndex = 40;
            this.label7.Text = "Japanese Subtitles";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.slidePic6);
            this.Controls.Add(this.slidePic1);
            this.Controls.Add(this.slidePic5);
            this.Controls.Add(this.slidePic4);
            this.Controls.Add(this.slidePic3);
            this.Controls.Add(this.slidePic2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelmenu);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            ((System.ComponentModel.ISupportInitialize)(this.slidePic6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidePic2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelmenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox slidePic6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox slidePic1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox slidePic5;
        private System.Windows.Forms.PictureBox slidePic4;
        private System.Windows.Forms.PictureBox slidePic3;
        private System.Windows.Forms.PictureBox slidePic2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelmenu;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}