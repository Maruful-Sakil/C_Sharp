﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviePlex
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            updateinfo obj = new updateinfo();
            obj.Show();
        }

        munibaEntities db = new munibaEntities();
        private void button11_Click(object sender, EventArgs e)
        {
            int UserId = int.Parse(Properties.Settings.Default.UserID);

            var record = db.tablesignups.Where(x => x.id == UserId).FirstOrDefault();
            if (record != null)
            {
                if (record.subscriptiontype == "Free")
                {
                    MessageBox.Show("Please Upgrade to get notificaions  !", "You are using free version", MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                }
                else
                {
                    MessageBox.Show("You are getting notifications", "Success! ",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }
    }
}
