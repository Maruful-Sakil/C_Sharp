﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviePlex
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private int imageNumber = 1;

        private void LoadNextImage()
        {
            if (imageNumber == 9)
            {
                imageNumber = 1;
            }
            slidePic1.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            slidePic2.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            slidePic3.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            slidePic4.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            slidePic5.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            slidePic6.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            //slidePic7.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            //slidePic8.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            //slidePic9.ImageLocation = string.Format(@"Newimg\{0}.jpg", imageNumber);
            imageNumber++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f6 = new Form6();
            f6.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadNextImage();
        }
    }
}
