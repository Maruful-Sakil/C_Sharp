﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviePlex
{
    public partial class updateinfo : Form
    {
        public updateinfo()
        {
            InitializeComponent();
        }

        private void textfirstname_TextChanged(object sender, EventArgs e)
        {

        }

        private void updateinfo_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form6 obj = new Form6();
            obj.Show();
        }
        munibaEntities db = new munibaEntities();
        private void updateinfo_Load(object sender, EventArgs e)
        {
            int recordid = int.Parse(Properties.Settings.Default.UserID);

            var record = db.tablesignups.Where(a => a.id == recordid).FirstOrDefault();
            if (record != null)
            {
                textfirstname.Text = record.firstname;
                txtlastname.Text = record.lastname;
                if (record.gender == "Male")
                {
                    gendercomboBox1.SelectedIndex = 0;
                }
                else
                {
                    gendercomboBox1.SelectedIndex = 1;
                }
                

            }
            dateofbirth.Text = record.dateofbirth;
            email.Text = record.email;
            phone.Text = record.phone;
            username.Text = record.username;
            password.Text = record.password;
if(record.region== "Dhaka")
            {
                region.SelectedIndex = 0; 
            }

else if(record.region == "Rajshahi")
            {
                region.SelectedIndex = 1;
            }

            else if (record.region == "Chittagong")
            {
                region.SelectedIndex = 2;
            }

            else if (record.region == "Sylhet")
            {
                region.SelectedIndex = 3;
            }
            else 
            {
                region.SelectedIndex = 4;
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int recordid = int.Parse(Properties.Settings.Default.UserID);

            var record = db.tablesignups.Where(a => a.id == recordid).FirstOrDefault();
            if (record != null)
            {
                record.firstname = textfirstname.Text;

                record.lastname = txtlastname.Text;

                if (record.gender == "Male")
                {
                    gendercomboBox1.SelectedIndex = 0;
                }
                else
                {
                    gendercomboBox1.SelectedIndex = 1;
                }


                record.dateofbirth   = dateofbirth.Text;
                record.email  = email.Text;
                record.phone  = phone .Text;
                record.username = username .Text;
                record.password = password.Text;
                if (record.region == "Dhaka")
                {
                    region.SelectedIndex = 0;
                }

                else if (record.region == "Rajshahi")
                {
                    region.SelectedIndex = 1;
                }

                else if (record.region == "Chittagong")
                {
                    region.SelectedIndex = 2;
                }

                else if (record.region == "Sylhet")
                {
                    region.SelectedIndex = 3;
                }
                else
                {
                    region.SelectedIndex = 4;
                }




                db.SaveChanges();

                MessageBox.Show("Record Updated Successfully", "Success",MessageBoxButtons.OK,MessageBoxIcon.Information);

                this.Hide();
                Form6 obj = new Form6();
                obj.Show();
            }

        }

        private void gendercomboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 obj = new Form6();
            obj.Show();
        }
    }
}
