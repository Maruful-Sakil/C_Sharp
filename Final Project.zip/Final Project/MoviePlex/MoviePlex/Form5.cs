﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviePlex
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        private int ImageNumber = 1;

        private void LoadNextImage()
        {
            if (ImageNumber == 9)
            {
                ImageNumber = 1;
            }
            slidePic1.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            slidePic2.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            slidePic3.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            slidePic4.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            slidePic5.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            slidePic6.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            //slidePic7.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            //slidePic8.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            //slidePic9.ImageLocation = string.Format(@"Upimg\{0}.jpg", ImageNumber);
            ImageNumber++;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 f6 = new Form6();
            f6.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f7 = new Form7();
            f7.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadNextImage();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You have turned on notification for upcoming movies", "Notification Enabled", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
