﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoviePlex
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Login/ Sign up first", "Login/Sign up to continue ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Login/ Sign up first", "Login/Sign up to continue ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Login/ Sign up first", "Login/Sign up to continue ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Login/ Sign up first", "Login/Sign up to continue ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please Login/ Sign up first", "Login/Sign up to continue ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        munibaEntities db = new munibaEntities();
        private void button5_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            var record = db.tablesignups.Where(a => a.username == username && a.password == password).FirstOrDefault();

            if (record != null)
            {
                if(textBox1.Text.Trim()!="" || textBox2.Text.Trim() != "")
                {
                    Properties.Settings.Default.UserID = record.id.ToString();
                    progressBar1.Visible = true;
                    progressBar1.Increment(100);
                    MessageBox.Show("Welcome to Movieplex", "Login Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    Form3 obj = new Form3();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Fields can not be blank", "Login failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }
            else
            {
                MessageBox.Show("Fields can not be blank", "Login failed!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            bool status = checkBox1.Checked;
            switch (status)
            {

                case true:
                    textBox2.UseSystemPasswordChar = false;
                    break;
                default:
                    textBox2.UseSystemPasswordChar = true;
                    break;
            }
        }
    }
}
