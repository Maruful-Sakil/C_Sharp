
Create database DBMovie


Use DBMovie

create table tablesignup
(
id int not null primary key identity(1,1),
firstname nvarchar(100),
lastname nvarchar(100),
gender nvarchar(100),
dateofbirth nvarchar(100),
email nvarchar(100),
phone nvarchar(100),
username nvarchar(100),
region nvarchar(100),
subscriptiontype nvarchar(100),
paymentmethod nvarchar(100),
password nvarchar(100),

)
select * from tablesignup;